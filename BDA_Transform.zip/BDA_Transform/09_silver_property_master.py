# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver Layer - Property Master Transformation
# MAGIC %md
# MAGIC # Silver Layer - Property Master Transformation
# MAGIC
# MAGIC **Purpose**: Transform bronze.property_json_extracts into silver.property_master based on BDA Lease Rent Challan System field schema.
# MAGIC
# MAGIC **Source**: `bronze.property_json_extracts`
# MAGIC **Target**: `silver.property_master`
# MAGIC
# MAGIC **Schema Mapping**:
# MAGIC * **Property Holder** tab fields
# MAGIC * **Property Details** tab fields (including 16 Part Payment Schedule columns)
# MAGIC * **Lease Details** tab fields  
# MAGIC * **Installment Details** tab fields
# MAGIC
# MAGIC **Operation**: Current-state MERGE on property_id (upsert - new extracts update existing properties, never duplicate)

# COMMAND ----------

# DBTITLE 1,Create Silver Schema
# MAGIC %sql
# MAGIC -- Create silver schema if it doesn't exist
# MAGIC CREATE SCHEMA IF NOT EXISTS silver
# MAGIC COMMENT 'Silver layer - transformed property master data based on BDA ERP schema';

# COMMAND ----------

# DBTITLE 1,Read Bronze and Parse JSON
from pyspark.sql import functions as F
from pyspark.sql.types import *
import json
import re
from datetime import datetime, timedelta

# Read from bronze layer
bronze_df = spark.table("bronze.property_json_extracts")

# ══════════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS (based on reference bda_json_to_excel.py)
# ══════════════════════════════════════════════════════════════════════════════

def safe_get(d, *keys, default=""):
    """Safely get nested dict values"""
    for k in keys:
        if not isinstance(d, dict):
            return default
        d = d.get(k, {})
    return d if d not in (None, {}, []) else default

def get_person(data, *roles):
    """Find first person matching any of the given roles"""
    for p in data.get("all_persons", []):
        if p.get("role") in roles:
            return p
    return {}

def get_timeline_event(data, *event_types):
    """Find first timeline event matching any of the event types"""
    for ev in data.get("global_timeline", []):
        if ev.get("event_type") in event_types:
            return ev
    return {}

def find_amount(data, *keywords):
    """Find amount entry where description contains all keywords"""
    for a in data.get("all_amounts", []):
        desc = str(a.get("description", "")).lower()
        if all(kw.lower() in desc for kw in keywords):
            return a
    return {}

def find_amounts_any(data, *keywords):
    """Find all amount entries where description contains any keyword"""
    results = []
    for a in data.get("all_amounts", []):
        desc = str(a.get("description", "")).lower()
        if any(kw.lower() in desc for kw in keywords):
            results.append(a)
    return results

def parse_address(addr):
    """Parse address into components"""
    if not addr:
        return {"addr1": "", "district": "", "state": "", "pincode": ""}
    
    parts = [p.strip() for p in re.split(r"[,;]", str(addr))]
    addr1 = ", ".join(parts[:min(3, len(parts))])
    district = state = pincode = ""
    
    cities = ["Bhopal", "Delhi", "New Delhi", "Mumbai", "Gurgaon", "Gurugram", "Noida",
              "Lucknow", "Agra", "Jaipur", "Chandigarh", "Meerut", "Indore", "Sehore"]
    states = ["Madhya Pradesh", "MP", "Haryana", "Rajasthan", "UP", "Uttar Pradesh",
              "Maharashtra", "Delhi", "Punjab", "Uttarakhand", "Gujarat"]
    
    for p in parts:
        for c in cities:
            if c.lower() in p.lower():
                district = c
        for s in states:
            if s.lower() in p.lower():
                state = p.strip()
        m = re.search(r'\b(\d{6})\b', p)
        if m:
            pincode = m.group(1)
    
    return {"addr1": addr1, "district": district, "state": state, "pincode": pincode}

def derive_property_id(data):
    """Derive property ID with fallback logic"""
    pd = data.get("property_details", {})
    for k in ("bda_property_id", "bda_property_id_alt", "regdept_property_id"):
        v = pd.get(k)
        if v:
            return str(v)
    plot = pd.get("plot_number", "")
    if plot:
        # BDA standard: 6626 (Bhopal) + 00000 + plot number
        return f"662600000{plot}".replace(" ", "")
    doc_ids = data.get("doc_ids", [])
    if doc_ids:
        return str(doc_ids[0])
    return "unknown"

def extract_relation_type(relation):
    """Extract relation type (S/O, W/O, D/O)"""
    if not relation:
        return "S/O"
    r = str(relation).upper()
    if "W/O" in r or "WIFE" in r:
        return "W/O"
    if "D/O" in r or "DAUGHTER" in r:
        return "D/O"
    return "S/O"

def extract_relation_name(relation):
    """Extract relation name from relation string"""
    if not relation:
        return ""
    for pfx in ["W/O", "S/O", "D/O", "w/o", "s/o", "d/o"]:
        if pfx in str(relation):
            return str(relation).split(pfx, 1)[-1].strip().lstrip("/ ")
    return str(relation)

def extract_rank_title(text):
    """Extract title from military rank or name"""
    if not text:
        return "Mr."
    t = str(text).upper()
    rank_map = [
        ("LT GEN", "Lt. Gen."), ("MAJ GEN", "Maj. Gen."), ("BRIG", "Brig."),
        ("WG CDR", "Wg. Cdr."), ("WING CDR", "Wg. Cdr."), ("FLT LT", "Flt. Lt."),
        ("SQN LDR", "Sqn. Ldr."), ("LT COL", "Lt. Col."), ("COL", "Col."),
        ("MAJ", "Maj."), ("CAPT", "Capt."), ("GEN", "Gen."), ("ADM", "Adm."),
        ("DR", "Dr."), ("SMT", "Smt."), ("SHRI", "Shri")
    ]
    for rank, title in rank_map:
        if rank in t:
            return title
    return "Mr."

def add_days_to_date(date_str, days):
    """Add calendar days to a date string"""
    if not date_str:
        return ""
    for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y"):
        try:
            dt = datetime.strptime(str(date_str), fmt)
            return (dt + timedelta(days=days)).strftime("%d/%m/%Y")
        except ValueError:
            continue
    return ""

def compute_installment_dates(allotment_date):
    """Compute 4 installment due dates at 60/240/420/600 days from allotment"""
    dates = []
    for d in (60, 240, 420, 600):
        dates.append(add_days_to_date(allotment_date, d))
    return dates

def clean_date(d):
    """Clean date string"""
    if not d:
        return ""
    return str(d).strip()

# ══════════════════════════════════════════════════════════════════════════════
# MAIN PARSER FUNCTION
# ══════════════════════════════════════════════════════════════════════════════

def parse_property_json(json_str):
    """Parse JSON and map to BDA ERP schema fields (improved with reference patterns)"""
    if not json_str:
        return None
    
    data = json.loads(json_str)
    
    # Extract core sections
    pd = data.get("property_details", {})
    summ = data.get("summary", {})
    
    # ── People ────────────────────────────────────────────────────────────────
    buyer = get_person(data, "current_owner_buyer", "original_allottee_vendor")
    if not buyer:
        # Fallback to first person
        all_persons = data.get("all_persons", [])
        buyer = all_persons[0] if all_persons else {}
    
    addr_info = parse_address(buyer.get("address", ""))
    
    # ── Timeline Events ───────────────────────────────────────────────────────
    allot_ev = get_timeline_event(data, "allotment", "application")
    lease_ev = get_timeline_event(data, "lease_deed")
    poss_ev = get_timeline_event(data, "possession")
    sale_ev = get_timeline_event(data, "sale_deed")
    
    allot_date = clean_date(allot_ev.get("date", ""))
    lease_date = clean_date(lease_ev.get("date", ""))
    
    # Allotment reference
    allot_ref = ""
    for kf in allot_ev.get("key_facts", []):
        if any(x in str(kf).lower() for x in ["allotment order", "letter no", "mr no"]):
            allot_ref = str(kf)
            break
    
    # Lease end date (30 years from lease start)
    lease_end = ""
    for kf in lease_ev.get("key_facts", []):
        kfl = str(kf).lower()
        if any(x in kfl for x in ["march 2036", "march 2066", "valid till", "ending on"]):
            lease_end = str(kf)
            break
    if not lease_end and lease_date:
        for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
            try:
                dt = datetime.strptime(lease_date, fmt)
                lease_end = f"31/03/{dt.year + 30}"
                break
            except ValueError:
                pass
    
    # ── Amounts ───────────────────────────────────────────────────────────────
    reg_fee_a = find_amount(data, "registration", "fee")
    plot_cost_a = find_amount(data, "total plot cost")
    if not plot_cost_a:
        plot_cost_a = find_amount(data, "plot cost")
    
    # Installment amounts sorted by date
    inst_list = sorted(
        [a for a in find_amounts_any(data, "instalment", "installment")
         if isinstance(a.get("amount"), (int, float))],
        key=lambda x: str(x.get("date", ""))
    )
    inst_amt_each = inst_list[0]["amount"] if inst_list else None
    
    # Calculate installment due dates from allotment date
    inst_due_dates = compute_installment_dates(allot_date) if allot_date else ["", "", "", ""]
    
    # Use actual paid dates if available
    actual_dates = [clean_date(a.get("date", "")) for a in inst_list]
    while len(actual_dates) < 4:
        actual_dates.append("")
    while len(inst_due_dates) < 4:
        inst_due_dates.append("")
    
    # Derive total plot cost: EMD + 4×installment
    emd_val = reg_fee_a.get("amount", None)
    total_cost = plot_cost_a.get("amount", None)
    if not total_cost and emd_val and inst_amt_each:
        total_cost = float(emd_val) + 4 * float(inst_amt_each)
    
    # Allotment balance = total_cost - emd
    allot_balance = None
    if total_cost and emd_val:
        allot_balance = float(total_cost) - float(emd_val)
    
    # Transfer/namantaran fee
    transfer_a = find_amount(data, "transfer fee")
    parivarthan_a = find_amount(data, "parivarthan")
    seva_val = parivarthan_a.get("amount") or transfer_a.get("amount")
    
    # Lease money one-time
    lease_money_a = find_amount(data, "lease money")
    if not lease_money_a:
        lease_money_a = find_amount(data, "one-time", "lease")
    
    # Outstanding
    outstanding_a = find_amount(data, "outstanding")
    outstanding_val = outstanding_a.get("amount", None)
    
    # Water charge proxy = annual rent
    annual_rent_a = find_amount(data, "annual rent")
    if not annual_rent_a:
        annual_rent_a = find_amount(data, "lease rent", "yearly")
    annual_rent = annual_rent_a.get("amount", None)
    
    water_per_month = annual_rent  # proxy
    water_months = 12
    water_total = (float(water_per_month) * water_months) if water_per_month else None
    
    # Lease interest rate
    lease_interest = 16.5
    for ev in data.get("global_timeline", []):
        for kf in ev.get("key_facts", []):
            m = re.search(r'(\d+\.?\d*)\s*%', str(kf))
            if m:
                candidate = float(m.group(1))
                if 10 <= candidate <= 25:
                    lease_interest = candidate
                    break
    
    # Property ID
    prop_id = derive_property_id(data)
    
    # Property unit
    area_sqm = pd.get("area_sqm", "")
    area_sqft = pd.get("area_sqft", "")
    prop_unit = "Sq. Mtr." if area_sqm else ("Sq. Ft." if area_sqft else "Sq. Mtr.")
    poss_area = area_sqm or area_sqft or ""
    
    # UpdateRemark — ownership chain
    chain_parts = []
    for step in summ.get("ownership_chain", []):
        chain_parts.append(
            f"[{step.get('step', '')}] {step.get('holder', '')} ({step.get('period', '')}) — {step.get('basis', '')}"
        )
    issues = summ.get("outstanding_issues", [])
    if issues:
        chain_parts.append("OUTSTANDING: " + "; ".join(issues[:3]))
    update_remark = " | ".join(chain_parts)
    
    # ── Assemble result ───────────────────────────────────────────────────────
    return {
        # Core property ID
        'property_id': prop_id,
        
        # PROPERTY HOLDER TAB FIELDS
        'initial_name': extract_rank_title(buyer.get("rank_history", "") or buyer.get("name_english", "")),
        'property_holder_name': buyer.get("name_english", "") or buyer.get("name", ""),
        'property_holder_name_hi': buyer.get("name_hindi", ""),
        'gender': "Male",  # default
        'relation_type': extract_relation_type(buyer.get("relation", "")),
        'relation_name': extract_relation_name(buyer.get("relation", "")),
        'telephone_no': buyer.get("telephone", ""),
        'mobile_no': buyer.get("mobile", ""),
        'email_id': buyer.get("email", "") or buyer.get("email_id", ""),
        'aadhar_no': buyer.get("aadhar", "") or buyer.get("aadhar_no", ""),
        'gst_no': buyer.get("gst", "") or buyer.get("gst_no", ""),
        'comm_address_1': addr_info["addr1"],
        'comm_district': addr_info["district"],
        'comm_state': addr_info["state"],
        'comm_pin_code': addr_info["pincode"],
        'permanent_address_1': buyer.get("permanent_address", "") or addr_info["addr1"],
        'permanent_district': addr_info["district"],
        'permanent_state': addr_info["state"],
        'permanent_pin_code': addr_info["pincode"],
        'parent_property_id': "",
        
        # PROPERTY DETAILS TAB FIELDS
        'scheme_name': pd.get("scheme", ""),
        'property_category': "Plot",
        'property_use': "Residential",
        'property_use_description': pd.get("category", ""),
        'property_no': str(pd.get("plot_number", "")),
        'sector': pd.get("sector", "") or pd.get("zone", ""),
        'update_remark': update_remark,
        'is_rental': "No",
        'certificate_order_doc_ref': f"Allotment Order: {allot_ref} | Lease Deed: {lease_date}",
        'demarcation_letter_doc_ref': f"Dimensions: {pd.get('dimensions', '')} = {poss_area} Sqm",
        'possession_area': str(poss_area),
        'property_unit': prop_unit,
        'free_hold_flag': "No",
        'transfer_ind': "Yes" if sale_ev else "No",
        'property_cost': str(total_cost) if total_cost else None,
        'emd_amt': str(emd_val) if emd_val else None,
        'allotment_order': str(allot_balance) if allot_balance else None,
        'samiti_shulk': None,
        'seva_prabhar': str(seva_val) if seva_val else None,
        'vividh_vyaya': str(transfer_a.get("amount", "")) if transfer_a.get("amount") else None,
        'extra_land_ind': "No",
        'extra_land_area': None,
        'extra_land_amount': None,
        'water_charge_per_month': str(water_per_month) if water_per_month else None,
        'water_charge_months': str(water_months) if water_per_month else None,
        'water_charge_total': str(water_total) if water_total else None,
        
        # Part Payment Schedule (16 columns)
        'part1_payment_pct': None,
        'part1_payment_amount': str(inst_list[0]["amount"]) if len(inst_list) > 0 else (str(inst_amt_each) if inst_amt_each else None),
        'part1_days': "60",
        'part1_last_pay_date': actual_dates[0] or inst_due_dates[0],
        'part2_payment_pct': None,
        'part2_payment_amount': str(inst_list[1]["amount"]) if len(inst_list) > 1 else (str(inst_amt_each) if inst_amt_each else None),
        'part2_days': "240",
        'part2_last_pay_date': actual_dates[1] or inst_due_dates[1],
        'part3_payment_pct': None,
        'part3_payment_amount': str(inst_list[2]["amount"]) if len(inst_list) > 2 else (str(inst_amt_each) if inst_amt_each else None),
        'part3_days': "420",
        'part3_last_pay_date': actual_dates[2] or inst_due_dates[2],
        'part4_payment_pct': None,
        'part4_payment_amount': str(inst_list[3]["amount"]) if len(inst_list) > 3 else (str(inst_amt_each) if inst_amt_each else None),
        'part4_days': "600",
        'part4_last_pay_date': actual_dates[3] or inst_due_dates[3],
        
        # LEASE DETAILS TAB FIELDS
        'one_time_paid_flag': "Yes" if lease_money_a else "No",
        'one_time_deposit_date': clean_date(lease_money_a.get("date", "")),
        'one_time_letter_no': str(lease_money_a.get("receipt_no", "")),
        'one_time_deposit_amount': str(lease_money_a.get("amount", "")) if lease_money_a.get("amount") else None,
        'original_lease_amount': str(annual_rent) if annual_rent else None,
        'lease_interest_rate': str(lease_interest),
        'lease_amount_after_renewal': "Up to 100% enhancement on renewal (per Lease Deed renewal clause)",
        'dispatch_allotment_no': allot_ref,
        'allotment_no': allot_ref or str(pd.get("plot_number", "")),
        'allotment_date': allot_date,
        'possession_date': clean_date(poss_ev.get("date", "")) or lease_date,
        'lease_deed_date': lease_date,
        'lease_start_date': lease_date,
        'first_lease_end_date': lease_end,
        'second_lease_end_date': None,
        'lease_done_date': lease_date,
        'first_lease_done_ind': "Yes" if lease_ev else "No",
        'first_lease_renewal_done_date': None,
        'second_lease_renewal_done_ind': "No",
        'second_lease_renewal_done_date': None,
        'is_partition': "No",
        
        # INSTALLMENT DETAILS TAB FIELDS
        'installment_yes_no': "Yes" if inst_list else "No",
        'installment_pay_mode': "Demand-based (60/240/420/600 days per BDA schedule)",
        'installment_amount': str(inst_amt_each) if inst_amt_each else None,
        'total_installment_count': str(len(inst_list)) if inst_list else "4",
        'installment_interest_rate': str(lease_interest),
        'installment_over_flag': "Yes" if inst_list else "No",
        'installment_start_date': actual_dates[0] if actual_dates[0] else inst_due_dates[0],
        'first_installment_pct': None,
        'first_installment_amount': str(inst_list[0]["amount"]) if inst_list else None,
        'remaining_installment_amount': str(outstanding_val) if outstanding_val else None,
        
        # Metadata
        'source_extract_id': None,
        'ingested_at': None,
        'city': pd.get("city", ""),
        'state': pd.get("state", "")
    }

# Register UDF
parse_udf = F.udf(parse_property_json, MapType(StringType(), StringType()))

print("✓ Enhanced JSON parser with reference patterns ready")

# COMMAND ----------

# DBTITLE 1,Transform Bronze to Silver DataFrame
# Apply parsing UDF to extract all fields
parsed_df = bronze_df.select(
    "extract_id",
    "ingested_at",
    parse_udf("raw_json").alias("parsed_data")
)

# Expand the map into individual columns
silver_df = parsed_df.select(
    # Property Holder fields
    F.col("parsed_data.property_id").alias("property_id"),
    F.col("parsed_data.initial_name").alias("initial_name"),
    F.col("parsed_data.property_holder_name").alias("property_holder_name"),
    F.col("parsed_data.property_holder_name_hi").alias("property_holder_name_hi"),
    F.col("parsed_data.gender").alias("gender"),
    F.col("parsed_data.relation_type").alias("relation_type"),
    F.col("parsed_data.relation_name").alias("relation_name"),
    F.col("parsed_data.telephone_no").alias("telephone_no"),
    F.col("parsed_data.mobile_no").alias("mobile_no"),
    F.col("parsed_data.email_id").alias("email_id"),
    F.col("parsed_data.aadhar_no").alias("aadhar_no"),
    F.col("parsed_data.gst_no").alias("gst_no"),
    F.col("parsed_data.comm_address_1").alias("comm_address_1"),
    F.col("parsed_data.comm_district").alias("comm_district"),
    F.col("parsed_data.comm_state").alias("comm_state"),
    F.col("parsed_data.comm_pin_code").alias("comm_pin_code"),
    F.col("parsed_data.permanent_address_1").alias("permanent_address_1"),
    F.col("parsed_data.permanent_district").alias("permanent_district"),
    F.col("parsed_data.permanent_state").alias("permanent_state"),
    F.col("parsed_data.permanent_pin_code").alias("permanent_pin_code"),
    F.col("parsed_data.parent_property_id").alias("parent_property_id"),
    
    # Property Details fields
    F.col("parsed_data.scheme_name").alias("scheme_name"),
    F.col("parsed_data.property_category").alias("property_category"),
    F.col("parsed_data.property_use").alias("property_use"),
    F.col("parsed_data.property_use_description").alias("property_use_description"),
    F.col("parsed_data.property_no").alias("property_no"),
    F.col("parsed_data.sector").alias("sector"),
    F.col("parsed_data.update_remark").alias("update_remark"),
    F.col("parsed_data.is_rental").alias("is_rental"),
    F.col("parsed_data.certificate_order_doc_ref").alias("certificate_order_doc_ref"),
    F.col("parsed_data.demarcation_letter_doc_ref").alias("demarcation_letter_doc_ref"),
    F.col("parsed_data.possession_area").alias("possession_area"),
    F.col("parsed_data.property_unit").alias("property_unit"),
    F.col("parsed_data.free_hold_flag").alias("free_hold_flag"),
    F.col("parsed_data.transfer_ind").alias("transfer_ind"),
    F.col("parsed_data.property_cost").alias("property_cost"),
    F.col("parsed_data.emd_amt").alias("emd_amt"),
    F.col("parsed_data.allotment_order").alias("allotment_order"),
    F.col("parsed_data.samiti_shulk").alias("samiti_shulk"),
    F.col("parsed_data.seva_prabhar").alias("seva_prabhar"),
    F.col("parsed_data.vividh_vyaya").alias("vividh_vyaya"),
    F.col("parsed_data.extra_land_ind").alias("extra_land_ind"),
    F.col("parsed_data.extra_land_area").alias("extra_land_area"),
    F.col("parsed_data.extra_land_amount").alias("extra_land_amount"),
    F.col("parsed_data.water_charge_per_month").alias("water_charge_per_month"),
    F.col("parsed_data.water_charge_months").alias("water_charge_months"),
    F.col("parsed_data.water_charge_total").alias("water_charge_total"),
    
    # Part Payment Schedule (16 columns)
    F.col("parsed_data.part1_payment_pct").alias("part1_payment_pct"),
    F.col("parsed_data.part1_payment_amount").alias("part1_payment_amount"),
    F.col("parsed_data.part1_days").alias("part1_days"),
    F.col("parsed_data.part1_last_pay_date").alias("part1_last_pay_date"),
    F.col("parsed_data.part2_payment_pct").alias("part2_payment_pct"),
    F.col("parsed_data.part2_payment_amount").alias("part2_payment_amount"),
    F.col("parsed_data.part2_days").alias("part2_days"),
    F.col("parsed_data.part2_last_pay_date").alias("part2_last_pay_date"),
    F.col("parsed_data.part3_payment_pct").alias("part3_payment_pct"),
    F.col("parsed_data.part3_payment_amount").alias("part3_payment_amount"),
    F.col("parsed_data.part3_days").alias("part3_days"),
    F.col("parsed_data.part3_last_pay_date").alias("part3_last_pay_date"),
    F.col("parsed_data.part4_payment_pct").alias("part4_payment_pct"),
    F.col("parsed_data.part4_payment_amount").alias("part4_payment_amount"),
    F.col("parsed_data.part4_days").alias("part4_days"),
    F.col("parsed_data.part4_last_pay_date").alias("part4_last_pay_date"),
    
    # Lease Details fields
    F.col("parsed_data.one_time_paid_flag").alias("one_time_paid_flag"),
    F.col("parsed_data.one_time_deposit_date").alias("one_time_deposit_date"),
    F.col("parsed_data.one_time_letter_no").alias("one_time_letter_no"),
    F.col("parsed_data.one_time_deposit_amount").alias("one_time_deposit_amount"),
    F.col("parsed_data.original_lease_amount").alias("original_lease_amount"),
    F.col("parsed_data.lease_interest_rate").alias("lease_interest_rate"),
    F.col("parsed_data.lease_amount_after_renewal").alias("lease_amount_after_renewal"),
    F.col("parsed_data.dispatch_allotment_no").alias("dispatch_allotment_no"),
    F.col("parsed_data.allotment_no").alias("allotment_no"),
    F.col("parsed_data.allotment_date").alias("allotment_date"),
    F.col("parsed_data.possession_date").alias("possession_date"),
    F.col("parsed_data.lease_deed_date").alias("lease_deed_date"),
    F.col("parsed_data.lease_start_date").alias("lease_start_date"),
    F.col("parsed_data.first_lease_end_date").alias("first_lease_end_date"),
    F.col("parsed_data.second_lease_end_date").alias("second_lease_end_date"),
    F.col("parsed_data.lease_done_date").alias("lease_done_date"),
    F.col("parsed_data.first_lease_done_ind").alias("first_lease_done_ind"),
    F.col("parsed_data.first_lease_renewal_done_date").alias("first_lease_renewal_done_date"),
    F.col("parsed_data.second_lease_renewal_done_ind").alias("second_lease_renewal_done_ind"),
    F.col("parsed_data.second_lease_renewal_done_date").alias("second_lease_renewal_done_date"),
    F.col("parsed_data.is_partition").alias("is_partition"),
    
    # Installment Details fields
    F.col("parsed_data.installment_yes_no").alias("installment_yes_no"),
    F.col("parsed_data.installment_pay_mode").alias("installment_pay_mode"),
    F.col("parsed_data.installment_amount").alias("installment_amount"),
    F.col("parsed_data.total_installment_count").alias("total_installment_count"),
    F.col("parsed_data.installment_interest_rate").alias("installment_interest_rate"),
    F.col("parsed_data.installment_over_flag").alias("installment_over_flag"),
    F.col("parsed_data.installment_start_date").alias("installment_start_date"),
    F.col("parsed_data.first_installment_pct").alias("first_installment_pct"),
    F.col("parsed_data.first_installment_amount").alias("first_installment_amount"),
    F.col("parsed_data.remaining_installment_amount").alias("remaining_installment_amount"),
    
    # Metadata
    F.col("extract_id").alias("source_extract_id"),
    F.col("ingested_at").alias("ingested_at"),
    F.col("parsed_data.city").alias("city"),
    F.col("parsed_data.state").alias("state"),
    F.current_timestamp().alias("transformed_at")
)

# Deduplicate by property_id, keeping the most recent extract
from pyspark.sql.window import Window

window_spec = Window.partitionBy("property_id").orderBy(F.col("ingested_at").desc())
silver_df = silver_df.withColumn("row_num", F.row_number().over(window_spec)) \
    .filter(F.col("row_num") == 1) \
    .drop("row_num")

print(f"Transformed {silver_df.count()} unique property records (deduplicated by property_id, keeping most recent)")
silver_df.show(5, truncate=False)

# COMMAND ----------

# DBTITLE 1,MERGE INTO silver.property_master
from delta.tables import DeltaTable

# MERGE: Update existing properties, insert new ones
target_table = DeltaTable.forName(spark, "silver.property_master")

merge_result = target_table.alias("target").merge(
    silver_df.alias("source"),
    "target.property_id = source.property_id"
).whenMatchedUpdateAll(
).whenNotMatchedInsertAll(
).execute()

print("✓ MERGE completed: existing properties updated, new properties inserted")
print(f"  Rows updated: {merge_result.rows_updated}")
print(f"  Rows inserted: {merge_result.rows_inserted}")

# Show result with improved field extraction
result_df = spark.sql("""
    SELECT 
        property_id,
        property_holder_name,
        scheme_name,
        sector,
        property_category,
        possession_area,
        property_unit,
        lease_deed_date,
        first_lease_end_date,
        allotment_date,
        part1_last_pay_date,
        part2_last_pay_date,
        update_remark,
        transformed_at
    FROM silver.property_master
    ORDER BY transformed_at DESC
""")

print(f"\nTotal properties in silver layer: {result_df.count()}")
result_df.show(5, truncate=False)

# COMMAND ----------

# DBTITLE 1,Verify Silver Table
# MAGIC %sql
# MAGIC -- Final verification query
# MAGIC SELECT 
# MAGIC     property_id,
# MAGIC     property_holder_name,
# MAGIC     scheme_name,
# MAGIC     property_category,
# MAGIC     sector,
# MAGIC     possession_area,
# MAGIC     property_unit,
# MAGIC     lease_deed_date,
# MAGIC     first_lease_end_date,
# MAGIC     city,
# MAGIC     state,
# MAGIC     source_extract_id,
# MAGIC     transformed_at
# MAGIC FROM silver.property_master
# MAGIC ORDER BY property_id;

# COMMAND ----------

