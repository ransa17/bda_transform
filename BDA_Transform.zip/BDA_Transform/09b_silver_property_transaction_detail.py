# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Silver Layer - Property Transaction Detail
# MAGIC %md
# MAGIC # Silver Layer - Property Transaction Detail
# MAGIC
# MAGIC **Purpose**: Extract and transform transaction history from bronze.property_json_extracts into silver.property_transaction_detail.
# MAGIC
# MAGIC **Source**: `bronze.property_json_extracts`
# MAGIC **Target**: `silver.property_transaction_detail`
# MAGIC
# MAGIC **Schema**: 
# MAGIC * property_id
# MAGIC * txn_sr_no (transaction serial number)
# MAGIC * txn_trans_no
# MAGIC * txn_trans_date
# MAGIC * txn_challan_no
# MAGIC * txn_challan_date
# MAGIC * txn_transaction_head
# MAGIC * txn_amount
# MAGIC * txn_additional_remark
# MAGIC * source_extract_id
# MAGIC * ingested_at
# MAGIC
# MAGIC **Operation**: MERGE on (property_id, txn_sr_no) - append-heavy pattern. New transactions are inserted, existing ones preserved. Safe to re-run on same extract without duplicating.

# COMMAND ----------

# DBTITLE 1,Read Bronze and Parse Transactions
from pyspark.sql import functions as F
from pyspark.sql.types import *
import json

# Read from bronze layer
bronze_df = spark.table("bronze.property_json_extracts")

def parse_transactions(json_str, property_id, extract_id, ingested_at):
    """Parse transaction array from JSON and return list of transaction records"""
    try:
        data = json.loads(json_str)
        transactions = []
        
        # Try different possible locations for transaction data
        txn_array = None
        
        # Look for transaction data in various structures
        if 'transactions' in data:
            txn_array = data['transactions']
        elif 'timeline' in data:
            # Timeline events might contain transaction info
            timeline = data.get('timeline', [])
            for event in timeline:
                if event.get('event_type') in ['payment', 'transaction', 'challan']:
                    txn_array = txn_array or []
                    txn_array.append(event)
        elif 'payment_history' in data:
            txn_array = data['payment_history']
        elif 'challan_details' in data:
            txn_array = data['challan_details']
        
        # If we found transactions, parse them
        if txn_array and isinstance(txn_array, list):
            for idx, txn in enumerate(txn_array, start=1):
                transactions.append({
                    'property_id': str(property_id),
                    'txn_sr_no': str(txn.get('txn_sr_no') or txn.get('serial_no') or idx),
                    'txn_trans_no': str(txn.get('transaction_no') or txn.get('trans_no') or ''),
                    'txn_trans_date': str(txn.get('transaction_date') or txn.get('trans_date') or txn.get('date') or ''),
                    'txn_challan_no': str(txn.get('challan_no') or txn.get('challan_number') or ''),
                    'txn_challan_date': str(txn.get('challan_date') or ''),
                    'txn_transaction_head': str(txn.get('transaction_head') or txn.get('payment_type') or txn.get('head') or ''),
                    'txn_amount': str(txn.get('amount') or txn.get('payment_amount') or '0'),
                    'txn_additional_remark': str(txn.get('remark') or txn.get('remarks') or txn.get('additional_remark') or ''),
                    'source_extract_id': str(extract_id),
                    'ingested_at': str(ingested_at)
                })
        
        return transactions
    except Exception as e:
        print(f"Error parsing transactions for property {property_id}: {e}")
        return []

# Register UDF that returns array of structs
transaction_schema = ArrayType(StructType([
    StructField("property_id", StringType(), False),
    StructField("txn_sr_no", StringType(), False),
    StructField("txn_trans_no", StringType(), True),
    StructField("txn_trans_date", StringType(), True),
    StructField("txn_challan_no", StringType(), True),
    StructField("txn_challan_date", StringType(), True),
    StructField("txn_transaction_head", StringType(), True),
    StructField("txn_amount", StringType(), True),
    StructField("txn_additional_remark", StringType(), True),
    StructField("source_extract_id", StringType(), True),
    StructField("ingested_at", StringType(), True)
]))

parse_txn_udf = F.udf(parse_transactions, transaction_schema)

print("Transaction parser function ready")

# COMMAND ----------

# DBTITLE 1,Extract and Explode Transactions
# Parse transactions from each property extract
transactions_df = bronze_df.select(
    "property_id",
    "extract_id",
    "ingested_at",
    parse_txn_udf(
        "raw_json",
        "property_id",
        "extract_id",
        "ingested_at"
    ).alias("transactions")
)

# Explode the array of transactions into individual rows
transactions_exploded = transactions_df.select(
    F.explode("transactions").alias("txn")
).select(
    "txn.*"
)

# Filter out any empty/null transactions
transactions_final = transactions_exploded.filter(
    (F.col("property_id").isNotNull()) & 
    (F.col("txn_sr_no").isNotNull())
)

# Add transformation timestamp
transactions_final = transactions_final.withColumn(
    "transformed_at", 
    F.current_timestamp()
)

txn_count = transactions_final.count()
print(f"Extracted {txn_count} transaction records from property extracts")

if txn_count > 0:
    transactions_final.show(10, truncate=False)
else:
    print("Note: No transaction arrays found in current JSON files. This is normal if transaction data is stored separately.")

# COMMAND ----------

# DBTITLE 1,MERGE INTO silver.property_transaction_detail
from delta.tables import DeltaTable

if transactions_final.count() > 0:
    # Check if target table exists
    if spark.catalog.tableExists("silver.property_transaction_detail"):
        # MERGE: Insert new transactions, preserve existing ones
        # Key on (property_id, txn_sr_no) to avoid duplicates
        target_table = DeltaTable.forName(spark, "silver.property_transaction_detail")
        
        target_table.alias("target").merge(
            transactions_final.alias("source"),
            "target.property_id = source.property_id AND target.txn_sr_no = source.txn_sr_no"
        ).whenNotMatchedInsertAll(
        ).execute()
        
        print("✓ MERGE completed: new transactions inserted, existing transactions preserved")
    else:
        # First run: CREATE table
        transactions_final.write \
            .format("delta") \
            .mode("overwrite") \
            .saveAsTable("silver.property_transaction_detail")
        
        print("✓ silver.property_transaction_detail table created")
    
    # Show result
    spark.sql("""
        SELECT property_id, txn_sr_no, txn_trans_no, txn_trans_date, 
               txn_challan_no, txn_amount, transformed_at
        FROM silver.property_transaction_detail
        ORDER BY property_id, txn_sr_no
    """).show(truncate=False)
else:
    print("✓ No transactions to load in this run")

# COMMAND ----------

# DBTITLE 1,Verify Transaction Table
# Verify the transaction detail table
# Show transaction summary by property if table exists

if spark.catalog.tableExists("silver.property_transaction_detail"):
    result = spark.sql("""
        SELECT 
            property_id,
            COUNT(*) as total_transactions,
            SUM(CAST(txn_amount AS DECIMAL(18,2))) as total_amount,
            MIN(txn_trans_date) as first_transaction_date,
            MAX(txn_trans_date) as last_transaction_date,
            MAX(transformed_at) as last_updated
        FROM silver.property_transaction_detail
        GROUP BY property_id
        ORDER BY property_id
    """)
    display(result)
else:
    print("ℹ️ Table silver.property_transaction_detail does not exist yet.")
    print("This is expected when no transaction data is found in the source JSON files.")

# COMMAND ----------

# DBTITLE 1,Sample Transaction Details
# Sample individual transactions if table exists

if spark.catalog.tableExists("silver.property_transaction_detail"):
    result = spark.sql("""
        SELECT 
            property_id,
            txn_sr_no,
            txn_trans_no,
            txn_trans_date,
            txn_challan_no,
            txn_challan_date,
            txn_transaction_head,
            txn_amount,
            txn_additional_remark,
            source_extract_id
        FROM silver.property_transaction_detail
        ORDER BY property_id, txn_sr_no
        LIMIT 20
    """)
    display(result)
else:
    print("ℹ️ Table silver.property_transaction_detail does not exist yet.")
    print("No transaction data was found in the source JSON files.")

# COMMAND ----------

