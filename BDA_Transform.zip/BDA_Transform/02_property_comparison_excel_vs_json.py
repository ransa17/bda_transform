# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Property Comparison: Excel vs Silver/Gold Layer
# MAGIC %md
# MAGIC # Property Comparison: Excel vs Silver/Gold Layer
# MAGIC
# MAGIC **Purpose**: Compare uploaded Excel property data with the silver/gold transformations derived from JSON extracts.
# MAGIC
# MAGIC **Excel Files**:
# MAGIC * BDA_Plot01_HS_sample.xlsx
# MAGIC * BDA_Plot31A_Varma.xlsx  
# MAGIC * BDA_Plot37_RK.xlsx
# MAGIC * BDA_Plot39A_Trivedi.xlsx
# MAGIC * BDA_Plot133_SK.xlsx
# MAGIC * Plot38_Filled_Template.xlsx
# MAGIC
# MAGIC **Comparison Targets**:
# MAGIC * Silver: `silver.property_master`
# MAGIC * Gold: `gold.property_master_baseline`
# MAGIC
# MAGIC **Comparison Focus**: Property identification, holder details, property details, lease information, field-level differences

# COMMAND ----------

# DBTITLE 1,Define Excel Files Configuration
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType

# Excel file configurations with idbfs URLs
excel_files = [
    {"name": "BDA_Plot01_HS_sample.xlsx", "url": "idbfs:/2026-09-15/14/_f606c4e7-a28d-464c-b646-3f6b46343000", "plot_hint": "01", "label": "Plot01_HS"},
    {"name": "BDA_Plot31A_Varma.xlsx", "url": "idbfs:/2026-09-15/14/_1fdf3978-ad99-47e2-b581-e62e28505f47", "plot_hint": "31A", "label": "Plot31A_Varma"},
    {"name": "BDA_Plot37_RK.xlsx", "url": "idbfs:/2026-09-15/14/_2d99069c-7956-478b-9df1-6d30e0f695dc", "plot_hint": "37", "label": "Plot37_RK"},
    {"name": "BDA_Plot39A_Trivedi.xlsx", "url": "idbfs:/2026-09-15/14/_3e04e465-a30f-4342-8bd3-4f8a32828df3", "plot_hint": "39A", "label": "Plot39A_Trivedi"},
    {"name": "BDA_Plot133_SK.xlsx", "url": "idbfs:/2026-09-15/14/_7632505d-7063-4ee3-9346-55954401df90", "plot_hint": "133", "label": "Plot133_SK"},
    {"name": "Plot38_Filled_Template.xlsx", "url": "idbfs:/2026-09-15/14/_0ff7d90e-97df-4837-a7c4-aced49707229", "plot_hint": "38", "label": "Plot38"}
]

print(f"Configured {len(excel_files)} Excel files for comparison")

# COMMAND ----------

# DBTITLE 1,Extract Property Data from Excel Files
# Extract key property data from each Excel file
import json

excel_extracted_data = []

for excel_file in excel_files:
    file_url = excel_file["url"]
    
    try:
        # Try to read Property Holder sheet
        df_holder = spark.read.format("excel") \
            .option("dataAddress", "'👤 Property Holder'!A2:G25") \
            .option("header", "true") \
            .load(file_url)
        
        holder_data = {}
        for row in df_holder.collect():
            if row[0]:  # Field name exists
                field_name = str(row[0]).strip()
                field_value = str(row[1]) if row[1] else None
                holder_data[field_name] = field_value
        
        # Try to read Property Details sheet
        df_details = spark.read.format("excel") \
            .option("dataAddress", "'🏠 Property Details'!A2:G50") \
            .option("header", "true") \
            .load(file_url)
        
        details_data = {}
        for row in df_details.collect():
            if row[0]:  # Field name exists
                field_name = str(row[0]).strip()
                field_value = str(row[1]) if row[1] else None
                details_data[field_name] = field_value
        
        # Extract key identifiers
        property_no = details_data.get('Property Number', details_data.get('Property No.', excel_file['plot_hint']))
        
        excel_extracted_data.append({
            "excel_file": excel_file["name"],
            "property_id_excel": property_no,
            "property_holder_name": holder_data.get('Property Holder Name', holder_data.get('Holder Name')),
            "scheme_name": details_data.get('Scheme Name'),
            "property_category": details_data.get('Property Category'),
            "possession_area": details_data.get('Possession Area'),
            "sector": details_data.get('Sector'),
            "all_holder_fields": json.dumps(holder_data),
            "all_details_fields": json.dumps(details_data)
        })
        
        print(f"✓ Extracted data from {excel_file['label']}")
        
    except Exception as e:
        print(f"✗ Error reading {excel_file['label']}: {str(e)[:80]}")
        excel_extracted_data.append({
            "excel_file": excel_file["name"],
            "property_id_excel": excel_file['plot_hint'],
            "property_holder_name": None,
            "scheme_name": None,
            "property_category": None,
            "possession_area": None,
            "sector": None,
            "all_holder_fields": None,
            "all_details_fields": None
        })

# Create DataFrame from extracted Excel data with explicit schema
from pyspark.sql.types import StructType, StructField, StringType

excel_schema = StructType([
    StructField("excel_file", StringType(), True),
    StructField("property_id_excel", StringType(), True),
    StructField("property_holder_name", StringType(), True),
    StructField("scheme_name", StringType(), True),
    StructField("property_category", StringType(), True),
    StructField("possession_area", StringType(), True),
    StructField("sector", StringType(), True),
    StructField("all_holder_fields", StringType(), True),
    StructField("all_details_fields", StringType(), True)
])

excel_df = spark.createDataFrame(excel_extracted_data, schema=excel_schema)
display(excel_df.select("excel_file", "property_id_excel", "property_holder_name", "scheme_name", "possession_area"))

# COMMAND ----------

# DBTITLE 1,Load Gold Baseline for Comparison
# Load gold baseline properties
gold_df = spark.table("gold.property_master_baseline").select(
    "property_id",
    "property_holder_name",
    "property_no",
    "sector",
    "scheme_name",
    "property_category",
    "possession_area",
    "property_unit"
)

print(f"Gold baseline contains {gold_df.count()} properties")
display(gold_df)

# COMMAND ----------

# DBTITLE 1,Match Excel to Gold Properties
# Clean property IDs for fuzzy matching
excel_clean = excel_df.withColumn(
    "property_id_clean",
    F.regexp_replace(F.lower(F.col("property_id_excel")), "[^a-z0-9]", "")
)

gold_clean = gold_df.withColumn(
    "property_id_clean",
    F.regexp_replace(F.lower(F.col("property_id")), "[^a-z0-9]", "")
)

# Inner join to find matches
matched_properties = excel_clean.alias("excel").join(
    gold_clean.alias("gold"),
    F.col("excel.property_id_clean") == F.col("gold.property_id_clean"),
    "inner"
).select(
    F.col("excel.excel_file"),
    F.col("excel.property_id_excel").alias("excel_prop_id"),
    F.col("gold.property_id").alias("gold_prop_id"),
    F.col("excel.property_holder_name").alias("excel_holder"),
    F.col("gold.property_holder_name").alias("gold_holder"),
    F.col("excel.scheme_name").alias("excel_scheme"),
    F.col("gold.scheme_name").alias("gold_scheme"),
    F.col("excel.possession_area").alias("excel_area"),
    F.col("gold.possession_area").alias("gold_area"),
    F.col("excel.property_category").alias("excel_category"),
    F.col("gold.property_category").alias("gold_category")
)

print(f"\n✓ Found {matched_properties.count()} MATCHED properties between Excel and Gold")
display(matched_properties)

# COMMAND ----------

# DBTITLE 1,Field-Level Comparison for Matched Properties
# For matched properties, check which fields differ
field_comparison = matched_properties.withColumn(
    "holder_match",
    F.when(F.col("excel_holder").isNull() & F.col("gold_holder").isNull(), "NULL")
     .when(F.col("excel_holder") == F.col("gold_holder"), "MATCH")
     .otherwise("MISMATCH")
).withColumn(
    "scheme_match",
    F.when(F.col("excel_scheme").isNull() & F.col("gold_scheme").isNull(), "NULL")
     .when(F.col("excel_scheme") == F.col("gold_scheme"), "MATCH")
     .otherwise("MISMATCH")
).withColumn(
    "area_match",
    F.when(F.col("excel_area").isNull() & F.col("gold_area").isNull(), "NULL")
     .when(F.col("excel_area") == F.col("gold_area"), "MATCH")
     .otherwise("MISMATCH")
).withColumn(
    "category_match",
    F.when(F.col("excel_category").isNull() & F.col("gold_category").isNull(), "NULL")
     .when(F.col("excel_category") == F.col("gold_category"), "MATCH")
     .otherwise("MISMATCH")
)

print("\nField-level comparison for matched properties:")
display(field_comparison.select(
    "excel_file", "excel_prop_id", 
    "holder_match", "scheme_match", "area_match", "category_match"
))

# COMMAND ----------

# DBTITLE 1,Find Excel-Only Properties (Not in Gold)
# Find Excel properties without Gold match
unmatched_excel = excel_clean.alias("excel").join(
    gold_clean.alias("gold"),
    F.col("excel.property_id_clean") == F.col("gold.property_id_clean"),
    "left_anti"
).select(
    F.col("excel.excel_file"),
    F.col("excel.property_id_excel"),
    F.col("excel.property_holder_name"),
    F.col("excel.scheme_name"),
    F.col("excel.possession_area"),
    F.lit("EXCEL ONLY - NOT IN GOLD").alias("status")
)

print(f"\n⚠ Found {unmatched_excel.count()} Excel properties NOT in Gold layer")
display(unmatched_excel)

# COMMAND ----------

# DBTITLE 1,Find Gold-Only Properties (Not in Excel)
# Find Gold properties without Excel match
unmatched_gold = gold_clean.alias("gold").join(
    excel_clean.alias("excel"),
    F.col("gold.property_id_clean") == F.col("excel.property_id_clean"),
    "left_anti"
).select(
    F.col("gold.property_id"),
    F.col("gold.property_no"),
    F.col("gold.property_holder_name"),
    F.col("gold.scheme_name"),
    F.col("gold.possession_area"),
    F.lit("GOLD ONLY - NOT IN EXCEL").alias("status")
)

print(f"\n⚠ Found {unmatched_gold.count()} Gold properties NOT in Excel upload")
display(unmatched_gold)

# COMMAND ----------

# DBTITLE 1,Generate Summary Report
# Create summary report
total_excel = excel_df.count()
total_gold = gold_df.count()
total_matched = matched_properties.count()
total_excel_only = unmatched_excel.count()
total_gold_only = unmatched_gold.count()

# Count field differences in matched properties
field_diffs = field_comparison.select(
    F.sum(F.when(F.col("holder_match") == "DIFFER", 1).otherwise(0)).alias("holder_diffs"),
    F.sum(F.when(F.col("scheme_match") == "DIFFER", 1).otherwise(0)).alias("scheme_diffs"),
    F.sum(F.when(F.col("area_match") == "DIFFER", 1).otherwise(0)).alias("area_diffs"),
    F.sum(F.when(F.col("category_match") == "DIFFER", 1).otherwise(0)).alias("category_diffs")
).collect()[0]

summary_data = [
    ("Total Excel Files", total_excel),
    ("Total Gold Properties", total_gold),
    ("Matched Properties (Excel ↔ Gold)", total_matched),
    ("Excel-Only Properties", total_excel_only),
    ("Gold-Only Properties", total_gold_only),
    ("", None),
    ("Field Differences in Matched:", None),
    ("  - Holder Name Differences", field_diffs.holder_diffs),
    ("  - Scheme Name Differences", field_diffs.scheme_diffs),
    ("  - Possession Area Differences", field_diffs.area_diffs),
    ("  - Property Category Differences", field_diffs.category_diffs)
]

summary_df = spark.createDataFrame(summary_data, ["Metric", "Count"])

print("\n" + "="*70)
print("📊 EXCEL vs GOLD COMPARISON SUMMARY")
print("="*70)
display(summary_df)

# COMMAND ----------

# DBTITLE 1,Property Comparison: Excel vs JSON Bronze Layer
# MAGIC %md
# MAGIC # Property Comparison: Excel vs JSON Bronze Layer
# MAGIC
# MAGIC **Purpose**: Compare property data from uploaded Excel files with existing JSON extracts in bronze.property_json_extracts.
# MAGIC
# MAGIC **Excel Files**:
# MAGIC * BDA_Plot01_HS_sample.xlsx
# MAGIC * BDA_Plot31A_Varma.xlsx
# MAGIC * BDA_Plot37_RK.xlsx
# MAGIC * BDA_Plot39A_Trivedi.xlsx
# MAGIC * BDA_Plot133_SK.xlsx
# MAGIC * Plot38_Filled_Template.xlsx
# MAGIC
# MAGIC **Comparison Keys**: property_id, plot_number, BDA property identifiers

# COMMAND ----------

# DBTITLE 1,Load Excel Files from Upload
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType

# Excel file configurations with idbfs URLs
excel_files = [
    {"name": "BDA_Plot01_HS_sample.xlsx", "url": "idbfs:/2026-09-15/14/_f606c4e7-a28d-464c-b646-3f6b46343000", "plot_hint": "Plot01_HS"},
    {"name": "BDA_Plot31A_Varma.xlsx", "url": "idbfs:/2026-09-15/14/_1fdf3978-ad99-47e2-b581-e62e28505f47", "plot_hint": "Plot31A"},
    {"name": "BDA_Plot37_RK.xlsx", "url": "idbfs:/2026-09-15/14/_2d99069c-7956-478b-9df1-6d30e0f695dc", "plot_hint": "Plot37_RK"},
    {"name": "BDA_Plot39A_Trivedi.xlsx", "url": "idbfs:/2026-09-15/14/_3e04e465-a30f-4342-8bd3-4f8a32828df3", "plot_hint": "Plot39A"},
    {"name": "BDA_Plot133_SK.xlsx", "url": "idbfs:/2026-09-15/14/_7632505d-7063-4ee3-9346-55954401df90", "plot_hint": "Plot133_SK"},
    {"name": "Plot38_Filled_Template.xlsx", "url": "idbfs:/2026-09-15/14/_0ff7d90e-97df-4837-a7c4-aced49707229", "plot_hint": "Plot38"}
]

print(f"Configured {len(excel_files)} Excel files for comparison")

# COMMAND ----------

# DBTITLE 1,Extract Property Identifiers from Excel Overview Sheets
# Extract property identifiers from each Excel file's Overview sheet
excel_properties = []

for excel_file in excel_files:
    try:
        # Read from Overview sheet (most files have this)
        df_overview = spark.read.format("excel") \
            .option("dataAddress", "'📋 Overview'!A1:E50") \
            .option("header", "true") \
            .load(excel_file["url"])
        
        # Try to find property ID in the data
        property_id = None
        
        # Look for common property identifier patterns
        for row in df_overview.collect():
            for col_name in df_overview.columns:
                cell_value = str(row[col_name]).strip() if row[col_name] else ""
                
                # Check if this looks like a property field
                if any(keyword in cell_value.lower() for keyword in ['property', 'plot', 'bda']):
                    # Get the next column value as the property ID
                    col_idx = df_overview.columns.index(col_name)
                    if col_idx + 1 < len(df_overview.columns):
                        next_col = df_overview.columns[col_idx + 1]
                        property_id = str(row[next_col]) if row[next_col] else None
                        if property_id and property_id.lower() not in ['none', 'null', '']:
                            break
            if property_id:
                break
        
        # Fallback to plot hint from filename
        if not property_id or property_id.lower() in ['none', 'null', '']:
            property_id = excel_file["plot_hint"]
        
        excel_properties.append({
            "excel_file": excel_file["name"],
            "property_id_excel": property_id,
            "plot_hint": excel_file["plot_hint"]
        })
        
    except Exception as e:
        # If Overview sheet fails, use filename hint
        excel_properties.append({
            "excel_file": excel_file["name"],
            "property_id_excel": excel_file["plot_hint"],
            "plot_hint": excel_file["plot_hint"]
        })
        print(f"Note: Used filename hint for {excel_file['name']} - {str(e)[:100]}")

# Create DataFrame from extracted properties
excel_df = spark.createDataFrame(excel_properties)
display(excel_df)

# COMMAND ----------

# DBTITLE 1,Load Bronze JSON Properties
# Load bronze layer properties
bronze_df = spark.table("bronze.property_json_extracts") \
    .select(
        "property_id",
        "source_file",
        "extract_id",
        F.length("raw_json").alias("json_size_bytes"),
        "ingested_at"
    )

display(bronze_df)

# COMMAND ----------

# DBTITLE 1,Compare and Match Properties
# Perform fuzzy matching between Excel and Bronze properties
# Clean property IDs for matching
excel_clean = excel_df.withColumn(
    "property_id_clean",
    F.regexp_replace(F.lower(F.col("property_id_excel")), "[^a-z0-9]", "")
)

bronze_clean = bronze_df.withColumn(
    "property_id_clean",
    F.regexp_replace(F.lower(F.col("property_id")), "[^a-z0-9]", "")
)

# Join to find matches
matched_properties = excel_clean.alias("excel").join(
    bronze_clean.alias("bronze"),
    F.col("excel.property_id_clean") == F.col("bronze.property_id_clean"),
    "inner"
).select(
    F.col("excel.excel_file"),
    F.col("excel.property_id_excel").alias("excel_property_id"),
    F.col("bronze.property_id").alias("bronze_property_id"),
    F.col("bronze.source_file").alias("json_source_file"),
    F.col("bronze.json_size_bytes"),
    F.col("bronze.ingested_at"),
    F.lit("MATCHED").alias("status")
)

print(f"Found {matched_properties.count()} matched properties")
display(matched_properties)

# COMMAND ----------

# DBTITLE 1,Find Unmatched Excel Properties
# Find Excel properties without JSON matches
unmatched_excel = excel_clean.alias("excel").join(
    bronze_clean.alias("bronze"),
    F.col("excel.property_id_clean") == F.col("bronze.property_id_clean"),
    "left_anti"
).select(
    F.col("excel.excel_file"),
    F.col("excel.property_id_excel"),
    F.col("excel.plot_hint"),
    F.lit("NOT IN BRONZE").alias("status")
)

print(f"Found {unmatched_excel.count()} Excel properties without JSON match")
display(unmatched_excel)

# COMMAND ----------

# DBTITLE 1,Find Unmatched Bronze Properties
# Find Bronze properties without Excel matches
unmatched_bronze = bronze_clean.alias("bronze").join(
    excel_clean.alias("excel"),
    F.col("bronze.property_id_clean") == F.col("excel.property_id_clean"),
    "left_anti"
).select(
    F.col("bronze.property_id"),
    F.col("bronze.source_file"),
    F.col("bronze.json_size_bytes"),
    F.lit("NOT IN EXCEL").alias("status")
)

print(f"Found {unmatched_bronze.count()} Bronze properties without Excel match")
display(unmatched_bronze)

# COMMAND ----------

# DBTITLE 1,Summary Report
# Create summary report
summary = spark.createDataFrame([
    ("Total Excel Files", excel_df.count()),
    ("Total Bronze JSON Records", bronze_df.count()),
    ("Matched Properties", matched_properties.count()),
    ("Excel Only (Not in Bronze)", unmatched_excel.count()),
    ("Bronze Only (Not in Excel)", unmatched_bronze.count())
], ["Metric", "Count"])

print("\n" + "="*60)
print("PROPERTY COMPARISON SUMMARY")
print("="*60)
display(summary)

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,Advanced Matching Analysis
# MAGIC %md
# MAGIC ## 🔍 Advanced Matching Analysis
# MAGIC
# MAGIC The simple exact match failed because property IDs have variations:
# MAGIC * Excel: `Plot01_HS`, `Plot31A`, `Plot37_RK`, `Plot39A`, `Plot133_SK`, `Plot38`
# MAGIC * Bronze: `01`, `Plot31A_timeline`, `39`, `37`, `a700000133`
# MAGIC * Gold: `01`, `unknown`, `39`, `150`, `37`, `a700000133`
# MAGIC
# MAGIC Let's extract the plot number and match by numeric/alphanumeric portion.

# COMMAND ----------

# DBTITLE 1,Extract Plot Numbers for Smarter Matching
import re

# Function to extract plot number from various formats
def extract_plot_number(prop_id):
    if not prop_id:
        return None
    
    # Remove common prefixes and suffixes
    cleaned = prop_id.lower().replace('plot', '').replace('_timeline', '').replace('bda', '').replace('_', ' ')
    
    # Extract numeric portion with optional letter suffix (e.g., "01", "31A", "133")
    # More flexible pattern that works with or without word boundaries
    match = re.search(r'(\d+[a-z]?)', cleaned)
    if match:
        return match.group(1)
    
    return None

# Add extracted plot numbers to DataFrames
excel_with_plot = excel_df.withColumn(
    "plot_number",
    F.udf(extract_plot_number, StringType())(F.col("property_id_excel"))
)

bronze_with_plot = bronze_df.withColumn(
    "plot_number",
    F.udf(extract_plot_number, StringType())(F.col("property_id"))
)

gold_with_plot = gold_df.withColumn(
    "plot_number",
    F.udf(extract_plot_number, StringType())(F.col("property_id"))
)

print("Excel plot numbers:")
display(excel_with_plot.select("property_id_excel", "plot_number"))

print("\nBronze plot numbers:")
display(bronze_with_plot.select("property_id", "plot_number", "source_file"))

print("\nGold plot numbers:")
display(gold_with_plot.select("property_id", "plot_number", "property_holder_name"))

# COMMAND ----------

# DBTITLE 1,Improved Excel-to-Bronze-to-Gold Matching
# Match by plot number across all three sources
matched_all = excel_with_plot.alias("excel").join(
    bronze_with_plot.alias("bronze"),
    F.col("excel.plot_number") == F.col("bronze.plot_number"),
    "inner"
).join(
    gold_with_plot.alias("gold"),
    F.col("bronze.plot_number") == F.col("gold.plot_number"),
    "inner"
).select(
    F.col("excel.plot_number").alias("plot_no"),
    F.col("excel.excel_file"),
    F.col("excel.property_id_excel").alias("excel_id"),
    F.col("bronze.property_id").alias("bronze_id"),
    F.col("bronze.source_file").alias("json_file"),
    F.col("gold.property_id").alias("gold_id"),
    F.col("gold.property_holder_name").alias("holder_name"),
    F.col("gold.scheme_name")
).orderBy("plot_no")

print(f"\n✅ Found {matched_all.count()} properties matched across Excel → Bronze → Gold")
print("\nComplete Traceability:")
display(matched_all)

# COMMAND ----------

# DBTITLE 1,Final Comprehensive Summary
# Create comprehensive summary
total_excel = excel_df.count()
total_bronze = bronze_df.count()
total_gold = gold_df.count()
total_matched_all = matched_all.count()

# Properties with Bronze but no Gold
bronze_no_gold = bronze_with_plot.alias("bronze").join(
    gold_with_plot.alias("gold"),
    F.col("bronze.plot_number") == F.col("gold.plot_number"),
    "left_anti"
).count()

# Properties with Excel but no Bronze
excel_no_bronze = excel_with_plot.alias("excel").join(
    bronze_with_plot.alias("bronze"),
    F.col("excel.plot_number") == F.col("bronze.plot_number"),
    "left_anti"
).count()

final_summary = spark.createDataFrame([
    ("📁 Total Excel Files Uploaded", total_excel),
    ("🗄️ Total Bronze JSON Records", total_bronze),
    ("🏆 Total Gold Properties", total_gold),
    ("", None),
    ("✅ Matched Across All 3 Layers", total_matched_all),
    ("⚠️ Excel → No Bronze Match", excel_no_bronze),
    ("⚠️ Bronze → No Gold Match", bronze_no_gold),
    ("", None),
    ("📊 Data Completeness %", int((total_matched_all / total_excel) * 100) if total_excel > 0 else 0)
], ["Metric", "Count"])

print("\n" + "="*80)
print("🎯 FINAL PROPERTY COMPARISON SUMMARY - Excel vs Bronze vs Gold")
print("="*80)
print("\n📋 Upload-to-Production Traceability Analysis\n")
display(final_summary)