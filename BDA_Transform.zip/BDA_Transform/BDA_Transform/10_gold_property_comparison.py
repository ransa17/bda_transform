# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Gold Layer - Property Field Comparison
# MAGIC %md
# MAGIC # Gold Layer - Property Field Comparison
# MAGIC
# MAGIC **Purpose**: Field-by-field comparison between Silver property_master and ERP baseline to identify mismatches.
# MAGIC
# MAGIC **Source**: `silver.property_master`
# MAGIC **Baseline**: `gold.property_master_baseline` (ERP current state)
# MAGIC **Output**: 
# MAGIC * `gold.property_field_comparison` - Detailed field-level comparison results
# MAGIC * `gold.mismatch_inbox` - View of mismatched fields (red flags)
# MAGIC
# MAGIC **Comparison Logic**: 
# MAGIC * Each field is compared individually
# MAGIC * Matches = `status = 'MATCH'` (green/neutral)
# MAGIC * Mismatches = `status = 'MISMATCH'` (red flag)
# MAGIC * New records = `status = 'NEW'`
# MAGIC * Missing records = `status = 'MISSING'`
# MAGIC
# MAGIC **Workflow**: Run this after Silver layer updates to detect changes.

# COMMAND ----------

# DBTITLE 1,Create Gold Schema
# MAGIC %sql
# MAGIC -- Create gold schema if it doesn't exist
# MAGIC CREATE SCHEMA IF NOT EXISTS gold
# MAGIC COMMENT 'Gold layer - field-level comparison and change tracking for BDA property data';

# COMMAND ----------

# DBTITLE 1,Initialize Baseline Snapshot
# Initialize or update baseline from silver.property_master
# On first run: creates baseline from current silver state
# On subsequent runs: baseline remains as ERP reference point

from pyspark.sql import functions as F
from datetime import datetime

# Check if baseline exists
if not spark.catalog.tableExists("gold.property_master_baseline"):
    # First run: create baseline from silver
    baseline_df = spark.table("silver.property_master") \
        .withColumn("baseline_snapshot_date", F.current_timestamp()) \
        .withColumn("baseline_source", F.lit("initial_silver_snapshot"))
    
    baseline_df.write \
        .format("delta") \
        .mode("overwrite") \
        .saveAsTable("gold.property_master_baseline")
    
    print("✓ Created baseline snapshot from silver.property_master")
    print(f"  Properties in baseline: {baseline_df.count()}")
    print("  Note: This represents the ERP baseline for comparison.")
    print("  To update baseline with fresh ERP data, reload this table from ERP extract.")
else:
    baseline_count = spark.table("gold.property_master_baseline").count()
    print(f"✓ Baseline already exists with {baseline_count} properties")
    print("  Using existing baseline for comparison.")

# COMMAND ----------

# DBTITLE 1,Build Field-Level Comparison
from pyspark.sql import functions as F
from pyspark.sql.types import *
import json

# Read silver current state and gold baseline
silver_df = spark.table("silver.property_master")
baseline_df = spark.table("gold.property_master_baseline")

# Get list of fields to compare (all BDA ERP schema fields)
fields_to_compare = [
    # Property Holder fields
    'initial_name', 'property_holder_name', 'property_holder_name_hi', 'gender',
    'relation_type', 'relation_name', 'telephone_no', 'mobile_no', 'email_id',
    'aadhar_no', 'gst_no', 'comm_address_1', 'comm_district', 'comm_state',
    'comm_pin_code', 'permanent_address_1', 'permanent_district', 'permanent_state',
    'permanent_pin_code', 'parent_property_id',
    
    # Property Details fields
    'scheme_name', 'property_category', 'property_use', 'property_use_description',
    'property_no', 'sector', 'update_remark', 'is_rental', 'certificate_order_doc_ref',
    'demarcation_letter_doc_ref', 'possession_area', 'property_unit', 'free_hold_flag',
    'transfer_ind', 'property_cost', 'emd_amt', 'allotment_order', 'samiti_shulk',
    'seva_prabhar', 'vividh_vyaya', 'extra_land_ind', 'extra_land_area',
    'extra_land_amount', 'water_charge_per_month', 'water_charge_months',
    'water_charge_total',
    
    # Part Payment Schedule
    'part1_payment_pct', 'part1_payment_amount', 'part1_days', 'part1_last_pay_date',
    'part2_payment_pct', 'part2_payment_amount', 'part2_days', 'part2_last_pay_date',
    'part3_payment_pct', 'part3_payment_amount', 'part3_days', 'part3_last_pay_date',
    'part4_payment_pct', 'part4_payment_amount', 'part4_days', 'part4_last_pay_date',
    
    # Lease Details
    'one_time_paid_flag', 'one_time_deposit_date', 'one_time_letter_no',
    'one_time_deposit_amount', 'original_lease_amount', 'lease_interest_rate',
    'lease_amount_after_renewal', 'dispatch_allotment_no', 'allotment_no',
    'allotment_date', 'possession_date', 'lease_deed_date', 'lease_start_date',
    'first_lease_end_date', 'second_lease_end_date', 'lease_done_date',
    'first_lease_done_ind', 'first_lease_renewal_done_date',
    'second_lease_renewal_done_ind', 'second_lease_renewal_done_date', 'is_partition',
    
    # Installment Details
    'installment_yes_no', 'installment_pay_mode', 'installment_amount',
    'total_installment_count', 'installment_interest_rate', 'installment_over_flag',
    'installment_start_date', 'first_installment_pct', 'first_installment_amount',
    'remaining_installment_amount',
    
    # Additional fields
    'city', 'state'
]

print(f"Comparing {len(fields_to_compare)} fields across all properties")

# COMMAND ----------

# DBTITLE 1,Perform Field-by-Field Comparison
from datetime import datetime

# Full outer join to capture NEW, MISSING, and existing properties
# Use coalesce to get property_id from either side
joined_df = silver_df.alias("silver").join(
    baseline_df.alias("baseline"),
    silver_df.property_id == baseline_df.property_id,
    "full_outer"
).select(
    F.coalesce(F.col("silver.property_id"), F.col("baseline.property_id")).alias("property_id"),
    *[F.col(f"silver.{field}").alias(f"silver_{field}") for field in fields_to_compare],
    *[F.col(f"baseline.{field}").alias(f"baseline_{field}") for field in fields_to_compare],
    F.col("silver.property_id").alias("silver_property_id"),
    F.col("baseline.property_id").alias("baseline_property_id")
)

# Build comparison records for each field
comparison_records = []

for row in joined_df.collect():
    property_id = row['property_id']
    
    # Determine property status
    if row['silver_property_id'] is None:
        property_status = 'MISSING'  # In baseline but not in silver
    elif row['baseline_property_id'] is None:
        property_status = 'NEW'  # In silver but not in baseline
    else:
        property_status = 'EXISTS'
    
    # Compare each field
    for field in fields_to_compare:
        silver_value = row[f'silver_{field}']
        baseline_value = row[f'baseline_{field}']
        
        # Normalize None and empty strings for comparison
        silver_normalized = str(silver_value).strip() if silver_value else None
        baseline_normalized = str(baseline_value).strip() if baseline_value else None
        
        # Determine field status
        if property_status == 'NEW':
            field_status = 'NEW'
        elif property_status == 'MISSING':
            field_status = 'MISSING'
        elif silver_normalized is None and baseline_normalized is None:
            field_status = 'NULL'
        elif silver_normalized == baseline_normalized:
            field_status = 'MATCH'
        else:
            field_status = 'MISMATCH'
        
        comparison_records.append({
            'property_id': property_id,
            'field_name': field,
            'silver_value': silver_value,
            'baseline_value': baseline_value,
            'status': field_status,
            'property_status': property_status,
            'comparison_timestamp': datetime.now()
        })

print(f"Generated {len(comparison_records)} field comparison records")

# COMMAND ----------

# DBTITLE 1,Create Comparison DataFrame and Save
# Create DataFrame from comparison records
comparison_schema = StructType([
    StructField("property_id", StringType(), False),
    StructField("field_name", StringType(), False),
    StructField("silver_value", StringType(), True),
    StructField("baseline_value", StringType(), True),
    StructField("status", StringType(), False),
    StructField("property_status", StringType(), False),
    StructField("comparison_timestamp", TimestampType(), False)
])

comparison_df = spark.createDataFrame(comparison_records, schema=comparison_schema)

# Write to gold.property_field_comparison
comparison_df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("gold.property_field_comparison")

print(f"✓ Saved {comparison_df.count()} field comparisons to gold.property_field_comparison")

# Show summary
summary = comparison_df.groupBy("status").count().orderBy("status")
print("\nComparison Summary:")
summary.show()

# COMMAND ----------

# DBTITLE 1,Create Mismatch Inbox View
# MAGIC %sql
# MAGIC -- Create mismatch inbox view (red flags only)
# MAGIC CREATE OR REPLACE VIEW gold.mismatch_inbox AS
# MAGIC SELECT 
# MAGIC     property_id,
# MAGIC     field_name,
# MAGIC     baseline_value AS erp_current_value,
# MAGIC     silver_value AS extracted_value,
# MAGIC     status,
# MAGIC     property_status,
# MAGIC     comparison_timestamp,
# MAGIC     CASE 
# MAGIC         WHEN status = 'MISMATCH' THEN '🔴 MISMATCH'
# MAGIC         WHEN status = 'NEW' THEN '🟢 NEW PROPERTY'
# MAGIC         WHEN status = 'MISSING' THEN '🟠 MISSING FROM EXTRACT'
# MAGIC         WHEN status = 'NULL' THEN '⚪ NULL (BOTH EMPTY)'
# MAGIC         ELSE '✓ MATCH'
# MAGIC     END as display_status
# MAGIC FROM gold.property_field_comparison
# MAGIC WHERE status IN ('MISMATCH', 'NEW', 'MISSING', 'NULL')
# MAGIC ORDER BY 
# MAGIC     CASE status
# MAGIC         WHEN 'MISMATCH' THEN 1
# MAGIC         WHEN 'NEW' THEN 2
# MAGIC         WHEN 'MISSING' THEN 3
# MAGIC         WHEN 'NULL' THEN 4
# MAGIC     END,
# MAGIC     property_id,
# MAGIC     field_name;

# COMMAND ----------

# DBTITLE 1,Display Mismatch Inbox
# MAGIC %sql
# MAGIC -- Show all mismatches, new, and missing records
# MAGIC SELECT 
# MAGIC     display_status,
# MAGIC     property_id,
# MAGIC     field_name,
# MAGIC     erp_current_value,
# MAGIC     extracted_value,
# MAGIC     comparison_timestamp
# MAGIC FROM gold.mismatch_inbox
# MAGIC ORDER BY display_status, property_id, field_name
# MAGIC LIMIT 100;

# COMMAND ----------

# DBTITLE 1,Mismatch Statistics
# MAGIC %sql
# MAGIC -- Summary statistics by property and status
# MAGIC SELECT 
# MAGIC     status,
# MAGIC     COUNT(DISTINCT property_id) as properties_affected,
# MAGIC     COUNT(*) as total_field_issues,
# MAGIC     ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) as percentage
# MAGIC FROM gold.property_field_comparison
# MAGIC GROUP BY status
# MAGIC ORDER BY 
# MAGIC     CASE status
# MAGIC         WHEN 'MISMATCH' THEN 1
# MAGIC         WHEN 'NEW' THEN 2
# MAGIC         WHEN 'MISSING' THEN 3
# MAGIC         WHEN 'NULL' THEN 4
# MAGIC         WHEN 'MATCH' THEN 5
# MAGIC     END;

# COMMAND ----------

