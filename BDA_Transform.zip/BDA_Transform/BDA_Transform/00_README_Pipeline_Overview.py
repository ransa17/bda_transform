# Databricks notebook source
# DBTITLE 1,BDA Transform Pipeline - Complete Documentation
# MAGIC %md
# MAGIC # BDA_Transform Pipeline - Complete Documentation
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC This project implements a **medallion architecture** (Bronze → Silver → Gold) for the **BDA Lease Rent Challan System** property data, with field-by-field ERP comparison and change tracking.
# MAGIC
# MAGIC ## Data Flow
# MAGIC
# MAGIC ```
# MAGIC JSON Property Files (6 files)
# MAGIC     ↓
# MAGIC [Bronze Layer] - Raw ingestion
# MAGIC     ↓
# MAGIC [Silver Layer] - ERP schema transformation
# MAGIC     ↓
# MAGIC [Gold Layer] - Field-level comparison & change detection
# MAGIC     ↓
# MAGIC [Mismatch Inbox] - Red flags for mismatches
# MAGIC [Change Log] - Historical change tracking
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Project Structure
# MAGIC
# MAGIC ### **Source Data**
# MAGIC 📁 `source_data/` - Contains 6 JSON property files:
# MAGIC * HS.json
# MAGIC * Plot31A_timeline.json
# MAGIC * plot39_timeline.json
# MAGIC * plot150_timeline.json
# MAGIC * Rk_timeline.json
# MAGIC * SK_timeline.json
# MAGIC
# MAGIC ### **Bronze Layer (01_bronze_ingest_property_json)**
# MAGIC **Purpose**: Raw JSON ingestion
# MAGIC
# MAGIC **Output**: `bronze.property_json_extracts`
# MAGIC
# MAGIC **Schema**:
# MAGIC * `property_id` - Unique property identifier
# MAGIC * `raw_json` - Complete JSON document as string
# MAGIC * `source_file` - Original file name
# MAGIC * `extract_id` - Sequential extract number
# MAGIC * `ingested_at` - Ingestion timestamp
# MAGIC
# MAGIC **Run Frequency**: On-demand when new JSON files are available
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### **Silver Layer**
# MAGIC
# MAGIC #### **09_silver_property_master**
# MAGIC **Purpose**: Transform to BDA ERP field schema
# MAGIC
# MAGIC **Output**: `silver.property_master`
# MAGIC
# MAGIC **Schema Groups**:
# MAGIC 1. **Property Holder** (21 fields): Names, contact info, addresses, IDs
# MAGIC 2. **Property Details** (42+ fields): Scheme, category, area, costs, charges, 16 Part Payment Schedule columns
# MAGIC 3. **Lease Details** (22 fields): Dates, amounts, renewal info, deed references
# MAGIC 4. **Installment Details** (10 fields): Payment terms, amounts, schedules
# MAGIC
# MAGIC **Operation**: MERGE on `property_id` (current-state upsert)
# MAGIC
# MAGIC **Run Frequency**: After Bronze ingestion
# MAGIC
# MAGIC #### **09b_silver_property_transaction_detail**
# MAGIC **Purpose**: Extract transaction history
# MAGIC
# MAGIC **Output**: `silver.property_transaction_detail`
# MAGIC
# MAGIC **Schema**:
# MAGIC * `property_id`, `txn_sr_no` (composite key)
# MAGIC * `txn_trans_no`, `txn_trans_date`, `txn_challan_no`, `txn_challan_date`
# MAGIC * `txn_transaction_head`, `txn_amount`, `txn_additional_remark`
# MAGIC * `source_extract_id`, `ingested_at`, `transformed_at`
# MAGIC
# MAGIC **Operation**: MERGE on `(property_id, txn_sr_no)` - append-heavy, safe to re-run
# MAGIC
# MAGIC **Run Frequency**: After Bronze ingestion
# MAGIC
# MAGIC **Note**: Current JSON files contain no transaction arrays - table created only when transaction data present
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### **Gold Layer**
# MAGIC
# MAGIC #### **10_gold_property_comparison**
# MAGIC **Purpose**: Field-by-field comparison against ERP baseline
# MAGIC
# MAGIC **Outputs**:
# MAGIC 1. `gold.property_master_baseline` - ERP reference snapshot
# MAGIC 2. `gold.property_field_comparison` - Detailed field-level comparison
# MAGIC 3. `gold.mismatch_inbox` (VIEW) - Red flags for mismatches
# MAGIC
# MAGIC **Comparison Status Values**:
# MAGIC * ✅ `MATCH` - Field values match (green/neutral)
# MAGIC * 🔴 `MISMATCH` - Field values differ (red flag)
# MAGIC * 🟢 `NEW` - Property exists in silver but not in baseline
# MAGIC * 🟡 `MISSING` - Property exists in baseline but not in silver
# MAGIC
# MAGIC **Run Frequency**: After Silver layer updates
# MAGIC
# MAGIC **First Run Behavior**: Creates baseline from current silver.property_master
# MAGIC
# MAGIC #### **11_gold_change_log**
# MAGIC **Purpose**: Track every field-level change over time
# MAGIC
# MAGIC **Outputs**:
# MAGIC 1. `gold.property_master_baseline_history` - Versioned baseline snapshots
# MAGIC 2. `gold.property_change_log` - Complete change history
# MAGIC
# MAGIC **Change Log Schema**:
# MAGIC * `property_id`, `field_name`
# MAGIC * `old_value`, `new_value`
# MAGIC * `change_type` (INSERT, UPDATE, DELETE)
# MAGIC * `change_detected_at`, `modified_by`
# MAGIC * `baseline_version_from`, `baseline_version_to`
# MAGIC
# MAGIC **Run Frequency**: After running 10_gold_property_comparison
# MAGIC
# MAGIC **Note**: `modified_by` field requires ERP extract to carry user/modification metadata
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Execution Order
# MAGIC
# MAGIC ### **Initial Setup** (First Time)
# MAGIC ```
# MAGIC 1. 01_bronze_ingest_property_json        → Ingest JSON files
# MAGIC 2. 09_silver_property_master              → Transform to ERP schema
# MAGIC 3. 09b_silver_property_transaction_detail → Extract transactions
# MAGIC 4. 10_gold_property_comparison            → Create baseline + first comparison
# MAGIC 5. 11_gold_change_log                     → Initialize change tracking
# MAGIC ```
# MAGIC
# MAGIC ### **Incremental Updates** (Subsequent Runs)
# MAGIC ```
# MAGIC 1. [Update source_data/ with new JSON files]
# MAGIC 2. 01_bronze_ingest_property_json        → Ingest new extracts
# MAGIC 3. 09_silver_property_master              → Update silver tables
# MAGIC 4. 09b_silver_property_transaction_detail → Update transactions
# MAGIC 5. 10_gold_property_comparison            → Detect mismatches
# MAGIC 6. 11_gold_change_log                     → Log detected changes
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Key Tables Reference
# MAGIC
# MAGIC | Layer | Table Name | Type | Purpose |
# MAGIC |-------|-----------|------|--------|
# MAGIC | **Bronze** | `bronze.property_json_extracts` | Delta | Raw JSON storage |
# MAGIC | **Silver** | `silver.property_master` | Delta | Current property state (ERP schema) |
# MAGIC | **Silver** | `silver.property_transaction_detail` | Delta | Transaction history (append-only) |
# MAGIC | **Gold** | `gold.property_master_baseline` | Delta | ERP reference snapshot |
# MAGIC | **Gold** | `gold.property_field_comparison` | Delta | Field-level comparison results |
# MAGIC | **Gold** | `gold.mismatch_inbox` | View | Mismatches only (red flags) |
# MAGIC | **Gold** | `gold.property_master_baseline_history` | Delta | Versioned baseline snapshots |
# MAGIC | **Gold** | `gold.property_change_log` | Delta | Complete change history |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Common Queries
# MAGIC
# MAGIC ### Find all mismatches for a property
# MAGIC ```sql
# MAGIC SELECT * FROM gold.mismatch_inbox
# MAGIC WHERE property_id = 'your_property_id'
# MAGIC ORDER BY field_name;
# MAGIC ```
# MAGIC
# MAGIC ### View change history for a property
# MAGIC ```sql
# MAGIC SELECT * FROM gold.property_change_log
# MAGIC WHERE property_id = 'your_property_id'
# MAGIC ORDER BY change_detected_at DESC;
# MAGIC ```
# MAGIC
# MAGIC ### Most frequently changed fields
# MAGIC ```sql
# MAGIC SELECT 
# MAGIC     field_name,
# MAGIC     COUNT(*) as change_count,
# MAGIC     COUNT(DISTINCT property_id) as properties_affected
# MAGIC FROM gold.property_change_log
# MAGIC GROUP BY field_name
# MAGIC ORDER BY change_count DESC;
# MAGIC ```
# MAGIC
# MAGIC ### Properties with most mismatches
# MAGIC ```sql
# MAGIC SELECT 
# MAGIC     property_id,
# MAGIC     COUNT(*) as mismatch_count
# MAGIC FROM gold.mismatch_inbox
# MAGIC WHERE status = 'MISMATCH'
# MAGIC GROUP BY property_id
# MAGIC ORDER BY mismatch_count DESC;
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Notes & Considerations
# MAGIC
# MAGIC ### **Baseline Management**
# MAGIC * First run of `10_gold_property_comparison` creates baseline from silver
# MAGIC * Baseline represents the ERP "current truth" for comparison
# MAGIC * To update baseline with fresh ERP data: reload `gold.property_master_baseline` from ERP extract
# MAGIC
# MAGIC ### **Transaction Data**
# MAGIC * Current JSON files contain no transaction arrays
# MAGIC * `silver.property_transaction_detail` created only when transaction data present
# MAGIC * Parser looks for: `transactions`, `timeline`, `payment_history`, `challan_details` arrays
# MAGIC
# MAGIC ### **Change Attribution**
# MAGIC * `modified_by` field in change log requires ERP extract metadata
# MAGIC * Without ERP metadata, `modified_by` remains NULL
# MAGIC * Timestamp (`change_detected_at`) always populated
# MAGIC
# MAGIC ### **Performance**
# MAGIC * Field-by-field comparison done in Python for flexibility
# MAGIC * For large datasets, consider SQL-based comparison for better performance
# MAGIC * Change log appends only - no updates or deletes
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Next Steps
# MAGIC
# MAGIC 1. **Add new JSON files** to `source_data/` folder
# MAGIC 2. **Run Bronze → Silver → Gold** pipeline in sequence
# MAGIC 3. **Query `mismatch_inbox`** to identify data quality issues
# MAGIC 4. **Review `change_log`** to track data evolution over time
# MAGIC 5. **Update baseline** when ERP data refreshes
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Support
# MAGIC
# MAGIC For questions or issues with this pipeline, refer to individual notebook documentation or contact the data engineering team.

# COMMAND ----------

