# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Gold Layer - Property Change Log
# MAGIC %md
# MAGIC # Gold Layer - Property Change Log
# MAGIC
# MAGIC **Purpose**: Track every field-level change detected in ERP data over time.
# MAGIC
# MAGIC **Source**: 
# MAGIC * `gold.property_master_baseline` (current ERP state)
# MAGIC * `gold.property_master_baseline_history` (previous snapshots)
# MAGIC
# MAGIC **Output**: `gold.property_change_log`
# MAGIC
# MAGIC **Schema**:
# MAGIC * `property_id` - Which property changed
# MAGIC * `field_name` - Which field changed
# MAGIC * `old_value` - Value before change
# MAGIC * `new_value` - Value after change
# MAGIC * `change_detected_at` - When the change was detected
# MAGIC * `modified_by` - Who made the change (from ERP extract metadata)
# MAGIC * `change_type` - INSERT, UPDATE, DELETE
# MAGIC
# MAGIC **Note**: The `modified_by` field can only be populated if the ERP extract includes user/modification metadata.

# COMMAND ----------

# DBTITLE 1,Create Baseline History Table
from pyspark.sql import functions as F
from datetime import datetime

# Check if baseline history exists
if not spark.catalog.tableExists("gold.property_master_baseline_history"):
    # First run: initialize history with current baseline
    current_baseline = spark.table("gold.property_master_baseline") \
        .withColumn("snapshot_version", F.lit(1)) \
        .withColumn("snapshot_timestamp", F.current_timestamp())
    
    current_baseline.write \
        .format("delta") \
        .mode("overwrite") \
        .saveAsTable("gold.property_master_baseline_history")
    
    print("✓ Initialized baseline history with current snapshot (version 1)")
    print("  No changes to log on first run.")
    initial_run = True
else:
    print("✓ Baseline history exists")
    version_count = spark.sql("""
        SELECT MAX(snapshot_version) as max_version 
        FROM gold.property_master_baseline_history
    """).collect()[0]['max_version']
    print(f"  Current snapshot version: {version_count}")
    initial_run = False

# COMMAND ----------

# DBTITLE 1,Create Change Log Table
from pyspark.sql.types import *

# Create change log table if it doesn't exist
if not spark.catalog.tableExists("gold.property_change_log"):
    change_log_schema = StructType([
        StructField("change_id", StringType(), False),
        StructField("property_id", StringType(), False),
        StructField("field_name", StringType(), False),
        StructField("old_value", StringType(), True),
        StructField("new_value", StringType(), True),
        StructField("change_type", StringType(), False),
        StructField("change_detected_at", TimestampType(), False),
        StructField("modified_by", StringType(), True),
        StructField("baseline_version_from", IntegerType(), True),
        StructField("baseline_version_to", IntegerType(), True)
    ])
    
    empty_df = spark.createDataFrame([], schema=change_log_schema)
    empty_df.write \
        .format("delta") \
        .mode("overwrite") \
        .saveAsTable("gold.property_change_log")
    
    print("✓ Created empty change log table")
else:
    change_count = spark.table("gold.property_change_log").count()
    print(f"✓ Change log exists with {change_count} historical changes")

# COMMAND ----------

# DBTITLE 0,Detect Changes from Previous Baseline
if not initial_run:
    # Get current baseline
    current_baseline = spark.table("gold.property_master_baseline")
    
    # Get previous baseline (latest snapshot from history)
    previous_baseline = spark.sql("""
        SELECT * FROM gold.property_master_baseline_history
        WHERE snapshot_version = (SELECT MAX(snapshot_version) FROM gold.property_master_baseline_history)
    """)
    
    previous_version = previous_baseline.select("snapshot_version").first()[0]
    new_version = previous_version + 1
    
    print(f"Comparing baseline version {previous_version} (previous) vs version {new_version} (current)")
    
    # Get list of fields to track
    fields_to_track = [
        'initial_name', 'property_holder_name', 'property_holder_name_hi', 'gender',
        'relation_type', 'relation_name', 'telephone_no', 'mobile_no', 'email_id',
        'aadhar_no', 'gst_no', 'comm_address_1', 'comm_district', 'comm_state',
        'comm_pin_code', 'permanent_address_1', 'permanent_district', 'permanent_state',
        'permanent_pin_code', 'parent_property_id', 'scheme_name', 'property_category',
        'property_use', 'property_use_description', 'property_no', 'sector',
        'update_remark', 'is_rental', 'certificate_order_doc_ref',
        'demarcation_letter_doc_ref', 'possession_area', 'property_unit',
        'free_hold_flag', 'transfer_ind', 'property_cost', 'emd_amt',
        'allotment_order', 'samiti_shulk', 'seva_prabhar', 'vividh_vyaya',
        'extra_land_ind', 'extra_land_area', 'extra_land_amount',
        'water_charge_per_month', 'water_charge_months', 'water_charge_total',
        'part1_payment_pct', 'part1_payment_amount', 'part1_days', 'part1_last_pay_date',
        'part2_payment_pct', 'part2_payment_amount', 'part2_days', 'part2_last_pay_date',
        'part3_payment_pct', 'part3_payment_amount', 'part3_days', 'part3_last_pay_date',
        'part4_payment_pct', 'part4_payment_amount', 'part4_days', 'part4_last_pay_date',
        'one_time_paid_flag', 'one_time_deposit_date', 'one_time_letter_no',
        'one_time_deposit_amount', 'original_lease_amount', 'lease_interest_rate',
        'lease_amount_after_renewal', 'dispatch_allotment_no', 'allotment_no',
        'allotment_date', 'possession_date', 'lease_deed_date', 'lease_start_date',
        'first_lease_end_date', 'second_lease_end_date', 'lease_done_date',
        'first_lease_done_ind', 'first_lease_renewal_done_date',
        'second_lease_renewal_done_ind', 'second_lease_renewal_done_date',
        'is_partition', 'installment_yes_no', 'installment_pay_mode',
        'installment_amount', 'total_installment_count', 'installment_interest_rate',
        'installment_over_flag', 'installment_start_date', 'first_installment_pct',
        'first_installment_amount', 'remaining_installment_amount', 'city', 'state'
    ]
    
    # Full outer join to detect inserts, updates, deletes
    curr_cols = [F.col(f"curr.{c}").alias(f"curr.{c}") for c in ["property_id"] + fields_to_track]
    prev_cols = [F.col(f"prev.{c}").alias(f"prev.{c}") for c in ["property_id"] + fields_to_track]
    
    joined = current_baseline.alias("curr").join(
        previous_baseline.alias("prev"),
        F.col("curr.property_id") == F.col("prev.property_id"),
        "full_outer"
    ).select(*curr_cols, *prev_cols)
    
    change_records = []
    change_timestamp = datetime.now()
    
    for row in joined.collect():
        property_id = row['curr.property_id'] or row['prev.property_id']
        
        # Check for new property (INSERT)
        if row['prev.property_id'] is None:
            for field in fields_to_track:
                new_value = row[f'curr.{field}']
                if new_value:  # Only log non-null insertions
                    change_records.append({
                        'change_id': f"{property_id}_{field}_{new_version}",
                        'property_id': property_id,
                        'field_name': field,
                        'old_value': None,
                        'new_value': str(new_value),
                        'change_type': 'INSERT',
                        'change_detected_at': change_timestamp,
                        'modified_by': None,  # Extract from ERP metadata if available
                        'baseline_version_from': previous_version,
                        'baseline_version_to': new_version
                    })
        
        # Check for deleted property (DELETE)
        elif row['curr.property_id'] is None:
            for field in fields_to_track:
                old_value = row[f'prev.{field}']
                if old_value:  # Only log non-null deletions
                    change_records.append({
                        'change_id': f"{property_id}_{field}_{new_version}",
                        'property_id': property_id,
                        'field_name': field,
                        'old_value': str(old_value),
                        'new_value': None,
                        'change_type': 'DELETE',
                        'change_detected_at': change_timestamp,
                        'modified_by': None,
                        'baseline_version_from': previous_version,
                        'baseline_version_to': new_version
                    })
        
        # Check for updated fields (UPDATE)
        else:
            for field in fields_to_track:
                old_value = row[f'prev.{field}']
                new_value = row[f'curr.{field}']
                
                # Normalize for comparison
                old_normalized = str(old_value).strip() if old_value else None
                new_normalized = str(new_value).strip() if new_value else None
                
                # Detect change
                if old_normalized != new_normalized:
                    change_records.append({
                        'change_id': f"{property_id}_{field}_{new_version}",
                        'property_id': property_id,
                        'field_name': field,
                        'old_value': old_value,
                        'new_value': new_value,
                        'change_type': 'UPDATE',
                        'change_detected_at': change_timestamp,
                        'modified_by': None,  # Extract from ERP metadata if available
                        'baseline_version_from': previous_version,
                        'baseline_version_to': new_version
                    })
    
    print(f"Detected {len(change_records)} field-level changes")
else:
    print("Skipping change detection on initial run")
    change_records = []

# COMMAND ----------

# DBTITLE 1,Append Changes to Log
if change_records:
    # Stringify old_value/new_value for schema compatibility (raw values may be non-string)
    for record in change_records:
        if record['old_value'] is not None:
            record['old_value'] = str(record['old_value'])
        if record['new_value'] is not None:
            record['new_value'] = str(record['new_value'])
    
    # Create DataFrame from change records with explicit schema
    changes_df = spark.createDataFrame(change_records, schema=spark.table("gold.property_change_log").schema)
    
    # Append to change log
    changes_df.write \
        .format("delta") \
        .mode("append") \
        .saveAsTable("gold.property_change_log")
    
    print(f"✓ Appended {len(change_records)} changes to gold.property_change_log")
    
    # Show change summary
    print("\nChange Summary:")
    changes_df.groupBy("change_type").count().orderBy("change_type").show()
    
    # Update baseline history with new snapshot (align columns with history table schema)
    history_table = spark.table("gold.property_master_baseline_history")
    history_cols = history_table.columns
    baseline_cols = spark.table("gold.property_master_baseline").columns
    
    select_exprs = []
    for col_name in history_cols:
        if col_name == "snapshot_version":
            select_exprs.append(F.lit(new_version).cast("int").alias("snapshot_version"))
        elif col_name == "snapshot_timestamp":
            select_exprs.append(F.lit(change_timestamp).cast("timestamp").alias("snapshot_timestamp"))
        elif col_name in baseline_cols:
            select_exprs.append(F.col(col_name))
        else:
            col_type = history_table.schema[col_name].dataType
            select_exprs.append(F.lit(None).cast(col_type).alias(col_name))
    
    current_baseline_versioned = spark.table("gold.property_master_baseline").select(*select_exprs)
    
    current_baseline_versioned.write \
        .format("delta") \
        .mode("append") \
        .saveAsTable("gold.property_master_baseline_history")
    
    print(f"✓ Saved new baseline snapshot (version {new_version}) to history")
else:
    print("✓ No changes detected in this run")

# COMMAND ----------

# DBTITLE 1,View Recent Changes
# MAGIC %sql
# MAGIC -- Show most recent changes
# MAGIC SELECT 
# MAGIC     property_id,
# MAGIC     field_name,
# MAGIC     old_value,
# MAGIC     new_value,
# MAGIC     change_type,
# MAGIC     change_detected_at,
# MAGIC     modified_by,
# MAGIC     baseline_version_to as detected_in_version
# MAGIC FROM gold.property_change_log
# MAGIC ORDER BY change_detected_at DESC, property_id, field_name
# MAGIC LIMIT 50;

# COMMAND ----------

# DBTITLE 1,Change Statistics by Property
# MAGIC %sql
# MAGIC -- Properties with most changes over time
# MAGIC SELECT 
# MAGIC     property_id,
# MAGIC     COUNT(*) as total_changes,
# MAGIC     SUM(CASE WHEN change_type = 'INSERT' THEN 1 ELSE 0 END) as inserts,
# MAGIC     SUM(CASE WHEN change_type = 'UPDATE' THEN 1 ELSE 0 END) as updates,
# MAGIC     SUM(CASE WHEN change_type = 'DELETE' THEN 1 ELSE 0 END) as deletes,
# MAGIC     MIN(change_detected_at) as first_change,
# MAGIC     MAX(change_detected_at) as last_change
# MAGIC FROM gold.property_change_log
# MAGIC GROUP BY property_id
# MAGIC ORDER BY total_changes DESC
# MAGIC LIMIT 20;

# COMMAND ----------

# DBTITLE 1,Change Statistics by Field
# MAGIC %sql
# MAGIC -- Most frequently changed fields
# MAGIC SELECT 
# MAGIC     field_name,
# MAGIC     COUNT(*) as change_count,
# MAGIC     COUNT(DISTINCT property_id) as properties_affected,
# MAGIC     SUM(CASE WHEN change_type = 'UPDATE' THEN 1 ELSE 0 END) as updates,
# MAGIC     SUM(CASE WHEN change_type = 'INSERT' THEN 1 ELSE 0 END) as inserts,
# MAGIC     SUM(CASE WHEN change_type = 'DELETE' THEN 1 ELSE 0 END) as deletes
# MAGIC FROM gold.property_change_log
# MAGIC GROUP BY field_name
# MAGIC ORDER BY change_count DESC
# MAGIC LIMIT 30;

# COMMAND ----------

# DBTITLE 1,Deduplicate Change Log
# Deduplicate change log entries (remove duplicate appends from debugging runs)
before_count = spark.table("gold.property_change_log").count()

# Keep only the earliest occurrence of each change_id
deduped = spark.sql("""
    SELECT * FROM (
        SELECT *, ROW_NUMBER() OVER (PARTITION BY change_id ORDER BY change_detected_at ASC) as rn
        FROM gold.property_change_log
    ) WHERE rn = 1
""").drop("rn")

after_count = deduped.count()
removed = before_count - after_count

if removed > 0:
    deduped.write \
        .format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .saveAsTable("gold.property_change_log")
    print(f"✓ Removed {removed} duplicate rows ({before_count} → {after_count})")
else:
    print(f"✓ No duplicates found ({before_count} rows)")

# Show final counts by version and type
spark.sql("""
    SELECT baseline_version_to, change_type, COUNT(*) as count
    FROM gold.property_change_log
    GROUP BY baseline_version_to, change_type
    ORDER BY baseline_version_to, change_type
""").show()