# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Bronze Layer - Property JSON Ingestion
# MAGIC %md
# MAGIC # Bronze Layer - Property JSON Ingestion
# MAGIC
# MAGIC **Purpose**: Ingest JSON property extracts from BDA Lease Rent Challan System into bronze.property_json_extracts table.
# MAGIC
# MAGIC **Source Files**:
# MAGIC * HS.json
# MAGIC * Plot31A_timeline.json
# MAGIC * plot39_timeline.json
# MAGIC * plot150_timeline.json
# MAGIC * Rk_timeline.json
# MAGIC * SK_timeline.json
# MAGIC
# MAGIC **Target**: `bronze.property_json_extracts`
# MAGIC
# MAGIC **Schema Mapping**: Raw JSON is stored with metadata for both timeline-wise and page-wise downstream transformations in Silver layer.

# COMMAND ----------

# DBTITLE 1,Create Bronze Schema
# MAGIC %sql
# MAGIC -- Create bronze schema if it doesn't exist
# MAGIC CREATE SCHEMA IF NOT EXISTS bronze
# MAGIC COMMENT 'Bronze layer - raw ingestion of BDA property JSON extracts';

# COMMAND ----------

# DBTITLE 1,Read and Ingest JSON Files
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, TimestampType
import json
from datetime import datetime

# Source data directory
source_dir = "file:/Workspace/Users/shambhu.rana@invotechservices.com/BDA_Transform/source_data"

# List of JSON files to ingest
json_files = [
    "HS.json",
    "Plot31A_timeline.json",
    "plot39_timeline.json",
    "plot150_timeline.json",
    "Rk_timeline.json",
    "SK_timeline.json"
]

# Read each JSON file and prepare for ingestion
data_rows = []
extract_id = 1

for json_file in json_files:
    file_path = f"{source_dir}/{json_file}"
    
    # Read JSON file as text using Spark (works on Serverless)
    raw_json = spark.read.text(file_path).collect()
    raw_json = ''.join([row.value for row in raw_json])
    json_data = json.loads(raw_json)
    
    # Extract property_id (try different field names based on file structure)
    property_id = None
    if 'property_details' in json_data:
        property_id = (json_data['property_details'].get('bda_property_id') or 
                      json_data['property_details'].get('plot_number'))
    elif 'property_info' in json_data:
        property_id = (json_data['property_info'].get('property_id_bda') or 
                      json_data['property_info'].get('plot_number'))
    
    # If no property_id found, use filename as fallback
    if not property_id:
        property_id = json_file.replace('.json', '')
    
    data_rows.append((
        str(property_id),
        raw_json,
        json_file,
        extract_id,
        datetime.now()
    ))
    extract_id += 1

print(f"Prepared {len(data_rows)} records for ingestion")

# COMMAND ----------

# DBTITLE 1,Create Bronze Table and Insert Data
# Create DataFrame
schema = StructType([
    StructField("property_id", StringType(), False),
    StructField("raw_json", StringType(), False),
    StructField("source_file", StringType(), False),
    StructField("extract_id", StringType(), False),
    StructField("ingested_at", TimestampType(), False)
])

df = spark.createDataFrame(data_rows, schema)

# Write to bronze table (CREATE OR REPLACE to handle reruns)
df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .saveAsTable("bronze.property_json_extracts")

print(f"Successfully loaded {df.count()} records into bronze.property_json_extracts")

# COMMAND ----------

# DBTITLE 1,Verify Bronze Table
# MAGIC %sql
# MAGIC -- Verify the bronze table
# MAGIC SELECT 
# MAGIC     property_id,
# MAGIC     source_file,
# MAGIC     extract_id,
# MAGIC     LENGTH(raw_json) as json_size_bytes,
# MAGIC     ingested_at
# MAGIC FROM bronze.property_json_extracts
# MAGIC ORDER BY extract_id;

# COMMAND ----------

